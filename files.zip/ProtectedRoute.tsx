import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '@/hooks/useSubscription';
import { useAuth } from '@/hooks/useAuth';
import { Loader2 } from 'lucide-react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireSubscription?: boolean;
}

export default function ProtectedRoute({ 
  children, 
  requireSubscription = true 
}: ProtectedRouteProps) {
  const { user, loading: authLoading } = useAuth();
  const { isActive, loading: subLoading } = useSubscription();
  const navigate = useNavigate();

  useEffect(() => {
    // Se não está autenticado, redireciona para login
    if (!authLoading && !user) {
      navigate('/login', { replace: true });
      return;
    }

    // Se requer assinatura e não tem assinatura ativa, redireciona para pricing
    if (requireSubscription && !subLoading && !isActive && user) {
      navigate('/pricing', { replace: true });
    }
  }, [user, isActive, authLoading, subLoading, navigate, requireSubscription]);

  // Mostra loading enquanto verifica
  if (authLoading || (requireSubscription && subLoading)) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-slate-600">Verificando acesso...</p>
        </div>
      </div>
    );
  }

  // Se passou todas as verificações, renderiza o conteúdo
  if (user && (!requireSubscription || isActive)) {
    return <>{children}</>;
  }

  // Fallback: não renderiza nada enquanto redireciona
  return null;
}

// Exemplo de uso no Router:

/*
import ProtectedRoute from './components/ProtectedRoute';

// No seu arquivo de rotas:
{
  path: '/dashboard',
  element: (
    <ProtectedRoute requireSubscription={true}>
      <Dashboard />
    </ProtectedRoute>
  )
},
{
  path: '/calculadoras',
  element: (
    <ProtectedRoute requireSubscription={true}>
      <Calculadoras />
    </ProtectedRoute>
  )
},
{
  path: '/profile',
  element: (
    <ProtectedRoute requireSubscription={false}>
      <Profile />
    </ProtectedRoute>
  )
},
*/
