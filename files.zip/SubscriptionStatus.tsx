import { useSubscription } from '@/hooks/useSubscription';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  Calendar,
  CreditCard,
  Loader2 
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function SubscriptionStatus() {
  const { subscription, loading, isActive, isPastDue, isCanceled } = useSubscription();

  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-slate-400" />
          <span className="ml-2 text-slate-600">Carregando assinatura...</span>
        </div>
      </Card>
    );
  }

  if (!subscription) {
    return (
      <Card className="p-6 bg-amber-50 border-amber-200">
        <div className="flex items-start gap-4">
          <AlertCircle className="h-6 w-6 text-amber-600 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="font-semibold text-amber-900 mb-1">
              Nenhuma assinatura ativa
            </h3>
            <p className="text-sm text-amber-800 mb-4">
              Assine o Marcenaria Pro para acessar todas as funcionalidades.
            </p>
            <Button 
              size="sm"
              className="bg-amber-600 hover:bg-amber-700"
              onClick={() => window.location.href = '/pricing'}
            >
              Ver Planos
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  const getStatusBadge = () => {
    if (isActive) {
      return (
        <Badge className="bg-green-100 text-green-800 border-green-200">
          <CheckCircle className="h-3 w-3 mr-1" />
          Ativa
        </Badge>
      );
    }
    if (isPastDue) {
      return (
        <Badge className="bg-red-100 text-red-800 border-red-200">
          <AlertCircle className="h-3 w-3 mr-1" />
          Pagamento Pendente
        </Badge>
      );
    }
    if (isCanceled) {
      return (
        <Badge className="bg-slate-100 text-slate-800 border-slate-200">
          <XCircle className="h-3 w-3 mr-1" />
          Cancelada
        </Badge>
      );
    }
    return (
      <Badge variant="outline">
        {subscription.status}
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "dd 'de' MMMM 'de' yyyy", { locale: ptBR });
  };

  const getPlanName = () => {
    const interval = subscription.plan_interval === 'month' ? 'Mensal' : 'Anual';
    return `${subscription.plan_name} - ${interval}`;
  };

  return (
    <Card className="p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-slate-900 mb-1">
            Minha Assinatura
          </h3>
          <p className="text-sm text-slate-600">
            {getPlanName()}
          </p>
        </div>
        {getStatusBadge()}
      </div>

      <div className="space-y-4">
        {/* Informações da Assinatura */}
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-start gap-3">
            <Calendar className="h-5 w-5 text-slate-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs text-slate-500 mb-1">Renovação</p>
              <p className="text-sm font-medium text-slate-900">
                {formatDate(subscription.current_period_end)}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <CreditCard className="h-5 w-5 text-slate-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs text-slate-500 mb-1">Método de Pagamento</p>
              <p className="text-sm font-medium text-slate-900">
                Cartão de Crédito
              </p>
            </div>
          </div>
        </div>

        {/* Alertas */}
        {subscription.cancel_at_period_end && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <p className="text-sm text-amber-800">
              Sua assinatura será cancelada em{' '}
              <strong>{formatDate(subscription.current_period_end)}</strong>.
              Você ainda tem acesso até essa data.
            </p>
          </div>
        )}

        {isPastDue && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-sm text-red-800">
              Há um problema com seu pagamento. Atualize seu método de pagamento
              para continuar usando o serviço.
            </p>
          </div>
        )}

        {/* Botões de Ação */}
        <div className="pt-4 border-t border-slate-200 flex gap-3">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => {
              // TODO: Implementar portal de gerenciamento do Stripe
              console.log('Abrir portal de gerenciamento');
            }}
          >
            Gerenciar Assinatura
          </Button>
          
          {isActive && !subscription.cancel_at_period_end && (
            <Button
              variant="outline"
              size="sm"
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
              onClick={() => {
                // TODO: Implementar cancelamento
                console.log('Cancelar assinatura');
              }}
            >
              Cancelar
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
