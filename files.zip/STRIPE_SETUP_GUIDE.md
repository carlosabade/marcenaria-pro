# 🔧 Guia de Configuração Stripe - Marcenaria Pro

## 1️⃣ Criar Produtos e Preços no Stripe

### Passo 1: Acessar o Dashboard do Stripe
1. Acesse: https://dashboard.stripe.com
2. Vá em **Products** → **Add Product**

### Passo 2: Criar Produto "Marcenaria Pro"
```
Nome: Marcenaria Pro
Descrição: Sistema completo de gestão para marcenarias
```

### Passo 3: Criar Preços

**Preço Mensal:**
```
Tipo: Recurring
Valor: R$ 97,00
Intervalo: Monthly
ID gerado: price_xxxxxxxxxxxxx
```

**Preço Anual:**
```
Tipo: Recurring
Valor: R$ 970,00
Intervalo: Yearly
ID gerado: price_yyyyyyyyyyyyy
```

### Passo 4: Copiar os IDs dos Preços
Após criar, copie os IDs que começam com `price_` e atualize em:

**Arquivo: `Pricing.tsx`**
```typescript
stripePriceId: {
  monthly: 'price_xxxxxxxxxxxxx', // Substituir aqui
  yearly: 'price_yyyyyyyyyyyyy',  // Substituir aqui
}
```

---

## 2️⃣ Configurar Webhooks

### Passo 1: Criar Webhook
1. Stripe Dashboard → **Developers** → **Webhooks**
2. Clique em **Add Endpoint**

### Passo 2: Configurar URL
```
URL: https://[seu-projeto].supabase.co/functions/v1/stripe-webhook
```

### Passo 3: Selecionar Eventos
Marque apenas estes eventos:
- ✅ `checkout.session.completed`
- ✅ `invoice.payment_succeeded`
- ✅ `customer.subscription.updated`
- ✅ `customer.subscription.deleted`

### Passo 4: Copiar o Signing Secret
Após criar, copie o `whsec_xxxxxxxx` e adicione nas variáveis de ambiente do Supabase.

---

## 3️⃣ Variáveis de Ambiente (Supabase)

Acesse: **Supabase Dashboard** → **Settings** → **Edge Functions**

Adicione estas variáveis:

```env
STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxxxxxxxxxxxxxx
FRONTEND_URL=http://localhost:5173
```

**Produção:**
```env
STRIPE_SECRET_KEY=sk_live_xxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_live_xxxxxxxxxxxxxxxxxxxxx
FRONTEND_URL=https://seudominio.com
```

---

## 4️⃣ Rotas do Frontend

### Adicionar ao seu Router (App.tsx ou routes.tsx):

```typescript
import Pricing from './pages/Pricing';
import CheckoutSuccess from './pages/CheckoutSuccess';

// Adicionar às rotas:
{
  path: '/pricing',
  element: <Pricing />
},
{
  path: '/checkout/success',
  element: <CheckoutSuccess />
},
```

---

## 5️⃣ URLs de Sucesso/Cancelamento

Quando o Stripe redirecionar após o checkout, as URLs serão:

**Sucesso:**
```
http://localhost:5173/checkout/success?session_id={CHECKOUT_SESSION_ID}
```

**Cancelamento:**
```
http://localhost:5173/pricing
```

Estas URLs são configuradas automaticamente pela function `create-checkout`.

---

## 6️⃣ Testar Integração

### Modo Teste (Stripe Test Mode)

Use estes cartões de teste:

**Sucesso:**
```
Número: 4242 4242 4242 4242
Data: Qualquer data futura
CVC: Qualquer 3 dígitos
```

**Pagamento Falha:**
```
Número: 4000 0000 0000 0002
```

**Requer Autenticação:**
```
Número: 4000 0025 0000 3155
```

### Fluxo de Teste:
1. Acesse `/pricing`
2. Clique em "Começar Agora"
3. Preencha com cartão de teste
4. Confirme pagamento
5. Aguarde redirecionamento para `/checkout/success`
6. Verifique no Supabase se a assinatura foi criada na tabela `subscriptions`

---

## 7️⃣ Verificar Webhooks

### No Stripe Dashboard:
1. Vá em **Developers** → **Webhooks**
2. Clique no webhook criado
3. Verifique a aba **Attempts** para ver se os eventos estão sendo recebidos
4. Status **Succeeded** = ✅ OK
5. Status **Failed** = ❌ Verificar logs no Supabase

### No Supabase:
1. Vá em **Edge Functions** → **stripe-webhook**
2. Clique em **Logs** para ver requisições
3. Procure por erros ou sucessos

---

## 8️⃣ Portal de Gerenciamento (Opcional)

Para permitir que usuários gerenciem assinaturas (atualizar cartão, cancelar, etc):

### Criar Function `create-portal-session`:

```typescript
// supabase/functions/create-portal-session/index.ts

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import Stripe from 'https://esm.sh/stripe@11.1.0?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2023-10-16',
})

serve(async (req) => {
  try {
    const { customerId } = await req.json()

    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${Deno.env.get('FRONTEND_URL')}/dashboard`,
    })

    return new Response(
      JSON.stringify({ url: session.url }),
      { headers: { 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    )
  }
})
```

### Deploy:
```bash
supabase functions deploy create-portal-session
```

---

## 9️⃣ Checklist Final

Antes de ir para produção:

- [ ] Produtos e preços criados no Stripe
- [ ] IDs dos preços atualizados no `Pricing.tsx`
- [ ] Webhook configurado e testado
- [ ] Variáveis de ambiente configuradas no Supabase
- [ ] Functions deployed (`create-checkout` e `stripe-webhook`)
- [ ] Rotas adicionadas no frontend
- [ ] Fluxo de pagamento testado em modo teste
- [ ] Tabela `subscriptions` criada no Supabase
- [ ] Logs dos webhooks sem erros

---

## 🆘 Troubleshooting

### Webhook não está sendo recebido:
- Verifique se a URL está correta
- Confirme que os eventos corretos foram selecionados
- Teste com `stripe trigger checkout.session.completed`

### Assinatura não aparece no banco:
- Verifique logs da function `stripe-webhook`
- Confirme que a tabela `subscriptions` existe
- Verifique RLS policies (pode precisar desabilitar temporariamente)

### Erro ao criar checkout:
- Confirme que `STRIPE_SECRET_KEY` está correta
- Verifique se os `priceId` estão corretos
- Confira logs da function `create-checkout`

---

## 📞 Suporte

Se encontrar problemas:
1. Verifique logs no Supabase Edge Functions
2. Verifique webhook attempts no Stripe Dashboard
3. Use o Stripe CLI para testar localmente: `stripe listen --forward-to localhost:54321/functions/v1/stripe-webhook`
