# 🚀 Integração Completa - Antigravity + Stripe

## 📁 Estrutura de Arquivos

```
src/
├── pages/
│   ├── Pricing.tsx              # ✅ Página de planos
│   ├── CheckoutSuccess.tsx      # ✅ Página de sucesso
│   └── Dashboard.tsx
├── components/
│   ├── ProtectedRoute.tsx       # ✅ Proteção de rotas
│   └── SubscriptionStatus.tsx   # ✅ Status da assinatura
├── hooks/
│   ├── useAuth.ts
│   └── useSubscription.ts       # ✅ Hook de assinatura
└── lib/
    └── supabase.ts
```

---

## 🔌 1. Integrar no Router Principal

### `App.tsx` ou `routes.tsx`:

```typescript
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Pricing from './pages/Pricing';
import CheckoutSuccess from './pages/CheckoutSuccess';
import Dashboard from './pages/Dashboard';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Rotas Públicas */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/checkout/success" element={<CheckoutSuccess />} />

        {/* Rotas Protegidas (requerem assinatura) */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute requireSubscription={true}>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/calculadoras"
          element={
            <ProtectedRoute requireSubscription={true}>
              <Calculadoras />
            </ProtectedRoute>
          }
        />
        <Route
          path="/projetos"
          element={
            <ProtectedRoute requireSubscription={true}>
              <Projetos />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
```

---

## 🎨 2. Adicionar Status no Dashboard

### `Dashboard.tsx`:

```typescript
import SubscriptionStatus from '@/components/SubscriptionStatus';

export default function Dashboard() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
      
      {/* Status da Assinatura */}
      <div className="mb-8">
        <SubscriptionStatus />
      </div>

      {/* Resto do conteúdo do dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Cards, gráficos, etc */}
      </div>
    </div>
  );
}
```

---

## 🛡️ 3. Verificar Assinatura em Componentes

### Exemplo: Bloquear funcionalidade sem assinatura

```typescript
import { useSubscription } from '@/hooks/useSubscription';
import { Button } from '@/components/ui/button';
import { Lock } from 'lucide-react';

export default function Calculadora() {
  const { isActive } = useSubscription();

  if (!isActive) {
    return (
      <div className="text-center py-12">
        <Lock className="h-16 w-16 text-slate-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-slate-900 mb-2">
          Assinatura Necessária
        </h2>
        <p className="text-slate-600 mb-6">
          Assine o Marcenaria Pro para acessar esta calculadora.
        </p>
        <Button onClick={() => window.location.href = '/pricing'}>
          Ver Planos
        </Button>
      </div>
    );
  }

  return (
    <div>
      {/* Conteúdo da calculadora */}
    </div>
  );
}
```

---

## 📊 4. Badge de Status no Header

### Exemplo: Mostrar status no menu superior

```typescript
import { useSubscription } from '@/hooks/useSubscription';
import { Badge } from '@/components/ui/badge';
import { Crown } from 'lucide-react';

export default function Header() {
  const { subscription, isActive } = useSubscription();

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <h1 className="text-xl font-bold">Marcenaria Pro</h1>
          
          {/* Badge de Status */}
          {isActive && (
            <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white">
              <Crown className="h-3 w-3 mr-1" />
              Pro {subscription?.plan_interval === 'year' ? 'Anual' : 'Mensal'}
            </Badge>
          )}
        </div>

        <nav className="flex items-center gap-4">
          <a href="/dashboard">Dashboard</a>
          <a href="/pricing">Planos</a>
        </nav>
      </div>
    </header>
  );
}
```

---

## 🔔 5. Notificações de Status

### Exemplo: Alert quando assinatura expira em breve

```typescript
import { useSubscription } from '@/hooks/useSubscription';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';
import { differenceInDays } from 'date-fns';

export default function SubscriptionAlert() {
  const { subscription, isActive } = useSubscription();

  if (!subscription || !isActive) return null;

  const daysUntilRenewal = differenceInDays(
    new Date(subscription.current_period_end),
    new Date()
  );

  // Mostrar alerta se faltam menos de 7 dias
  if (daysUntilRenewal <= 7 && daysUntilRenewal > 0) {
    return (
      <Alert className="mb-6 bg-amber-50 border-amber-200">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-800">
          Sua assinatura renova em {daysUntilRenewal} dia(s). 
          Certifique-se que seu método de pagamento está atualizado.
        </AlertDescription>
      </Alert>
    );
  }

  // Assinatura cancelada mas ainda ativa
  if (subscription.cancel_at_period_end) {
    return (
      <Alert className="mb-6 bg-red-50 border-red-200">
        <AlertTriangle className="h-4 w-4 text-red-600" />
        <AlertDescription className="text-red-800">
          Sua assinatura foi cancelada e expirará em {daysUntilRenewal} dia(s).
          {' '}
          <a href="/pricing" className="underline font-medium">
            Reativar assinatura
          </a>
        </AlertDescription>
      </Alert>
    );
  }

  return null;
}
```

---

## 🎯 6. Personalizar Experiência por Plano

### Exemplo: Recursos diferentes por tipo de plano

```typescript
import { useSubscription } from '@/hooks/useSubscription';

export default function Features() {
  const { subscription } = useSubscription();

  const limits = {
    monthly: {
      maxProjects: 50,
      maxClients: 100,
      storage: '5GB'
    },
    yearly: {
      maxProjects: 999,
      maxClients: 999,
      storage: '20GB'
    }
  };

  const currentLimits = subscription?.plan_interval === 'year' 
    ? limits.yearly 
    : limits.monthly;

  return (
    <div>
      <h3>Seus Limites</h3>
      <ul>
        <li>Projetos: até {currentLimits.maxProjects}</li>
        <li>Clientes: até {currentLimits.maxClients}</li>
        <li>Armazenamento: {currentLimits.storage}</li>
      </ul>
      
      {subscription?.plan_interval === 'month' && (
        <p className="text-sm text-slate-600 mt-4">
          💡 Upgrade para anual e ganhe limites maiores!
        </p>
      )}
    </div>
  );
}
```

---

## 🧪 7. Testar Localmente

### Passo a passo:

1. **Iniciar o projeto:**
```bash
npm run dev
```

2. **Acessar `/pricing`:**
   - Deve mostrar os planos com preços corretos
   - Botão "Começar Agora" deve estar visível

3. **Clicar em "Começar Agora":**
   - Deve redirecionar para checkout do Stripe
   - Usar cartão de teste: `4242 4242 4242 4242`

4. **Completar pagamento:**
   - Deve redirecionar para `/checkout/success`
   - Deve mostrar "Processando..." → "Pagamento Confirmado!"
   - Deve redirecionar para `/dashboard`

5. **Verificar no Supabase:**
```sql
SELECT * FROM subscriptions WHERE user_id = 'seu-user-id';
```

6. **Acessar `/dashboard`:**
   - Deve mostrar o componente `SubscriptionStatus`
   - Status deve estar "Ativa"

---

## ✅ Checklist de Implementação

- [ ] Copiar todos os componentes para o projeto
- [ ] Instalar dependências: `npm install date-fns`
- [ ] Atualizar IDs dos preços no `Pricing.tsx`
- [ ] Adicionar rotas no `App.tsx`
- [ ] Configurar variáveis de ambiente no Supabase
- [ ] Testar fluxo completo de checkout
- [ ] Verificar proteção de rotas funcionando
- [ ] Testar webhooks do Stripe
- [ ] Verificar criação de subscription no banco
- [ ] Testar renovação de assinatura

---

## 🎨 Customização de Design

Todos os componentes usam **Tailwind CSS** e são totalmente customizáveis:

### Cores do Tema:
- Primária: `blue-600` / `indigo-600`
- Sucesso: `green-600`
- Alerta: `amber-600`
- Erro: `red-600`

### Gradientes:
```css
bg-gradient-to-r from-blue-600 to-indigo-600
bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50
```

Basta alterar as classes Tailwind para customizar!

---

## 🆘 Resolução de Problemas Comuns

### Problema: "Subscription not found"
**Solução:** Aguarde 3-5 segundos após pagamento. O webhook pode demorar.

### Problema: Redirecionamento não funciona
**Solução:** Verifique se `FRONTEND_URL` está correto no Supabase.

### Problema: Botão de assinatura não faz nada
**Solução:** Verifique console do navegador. Provavelmente falta variável de ambiente.

### Problema: Status não atualiza
**Solução:** Force refresh com `Ctrl + Shift + R` ou limpe cache.

---

## 📞 Próximos Passos

1. **Portal de Gerenciamento:** Permitir usuários atualizarem cartão/cancelarem
2. **Emails Transacionais:** Enviar confirmação de assinatura
3. **Analytics:** Rastrear conversões e cancelamentos
4. **Testes A/B:** Testar diferentes preços/copy
5. **Cupons de Desconto:** Oferecer promoções

---

Está tudo pronto! 🎉

Agora é só copiar os arquivos para o seu projeto e seguir o **STRIPE_SETUP_GUIDE.md** para configurar os preços e webhooks.
