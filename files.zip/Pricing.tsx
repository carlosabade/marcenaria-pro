import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Check, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

type BillingPeriod = 'monthly' | 'yearly';

interface Plan {
  id: string;
  name: string;
  description: string;
  monthlyPrice: number;
  yearlyPrice: number;
  stripePriceId: {
    monthly: string;
    yearly: string;
  };
  features: string[];
  popular?: boolean;
}

const plans: Plan[] = [
  {
    id: 'pro',
    name: 'Plano Pro',
    description: 'Perfeito para marcenarias em crescimento',
    monthlyPrice: 97,
    yearlyPrice: 970, // 2 meses grátis
    stripePriceId: {
      monthly: 'price_monthly_id', // Substituir pelo ID real do Stripe
      yearly: 'price_yearly_id',   // Substituir pelo ID real do Stripe
    },
    features: [
      'Projetos ilimitados',
      'Calculadoras profissionais',
      'Controle de custos completo',
      'Gestão de clientes',
      'Geração de orçamentos',
      'Contratos automáticos',
      'Suporte prioritário',
      'Atualizações gratuitas',
    ],
    popular: true,
  },
];

export default function Pricing() {
  const { user } = useAuth();
  const [billingPeriod, setBillingPeriod] = useState<BillingPeriod>('monthly');
  const [loading, setLoading] = useState<string | null>(null);

  const handleSubscribe = async (priceId: string, planName: string) => {
    if (!user) {
      toast.error('Faça login para assinar');
      return;
    }

    setLoading(priceId);

    try {
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: {
          priceId,
          userId: user.id,
          userEmail: user.email,
        },
      });

      if (error) throw error;

      if (data?.url) {
        window.location.href = data.url;
      } else {
        throw new Error('URL de checkout não recebida');
      }
    } catch (error) {
      console.error('Erro ao criar checkout:', error);
      toast.error('Erro ao processar pagamento. Tente novamente.');
    } finally {
      setLoading(null);
    }
  };

  const getPrice = (plan: Plan) => {
    return billingPeriod === 'monthly' ? plan.monthlyPrice : plan.yearlyPrice;
  };

  const getPriceId = (plan: Plan) => {
    return billingPeriod === 'monthly' 
      ? plan.stripePriceId.monthly 
      : plan.stripePriceId.yearly;
  };

  const getSavings = (plan: Plan) => {
    if (billingPeriod === 'yearly') {
      const yearlySavings = (plan.monthlyPrice * 12) - plan.yearlyPrice;
      return yearlySavings;
    }
    return 0;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Escolha seu plano
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Profissionalize sua marcenaria com ferramentas completas de gestão
          </p>
        </div>

        {/* Toggle Mensal/Anual */}
        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-full p-1 shadow-sm border border-slate-200">
            <button
              onClick={() => setBillingPeriod('monthly')}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                billingPeriod === 'monthly'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mensal
            </button>
            <button
              onClick={() => setBillingPeriod('yearly')}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                billingPeriod === 'yearly'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Anual
              <span className="ml-2 text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
                Economize 2 meses
              </span>
            </button>
          </div>
        </div>

        {/* Cards de Planos */}
        <div className="grid md:grid-cols-1 gap-8 max-w-lg mx-auto">
          {plans.map((plan) => {
            const price = getPrice(plan);
            const priceId = getPriceId(plan);
            const savings = getSavings(plan);
            const isLoading = loading === priceId;

            return (
              <Card
                key={plan.id}
                className={`relative overflow-hidden transition-all hover:shadow-2xl ${
                  plan.popular
                    ? 'border-2 border-blue-500 shadow-xl scale-105'
                    : 'border border-slate-200'
                }`}
              >
                {/* Badge Popular */}
                {plan.popular && (
                  <div className="absolute top-0 right-0 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-1 text-xs font-semibold">
                    MAIS POPULAR
                  </div>
                )}

                <div className="p-8">
                  {/* Nome e Descrição */}
                  <div className="mb-6">
                    <h3 className="text-2xl font-bold text-slate-900 mb-2">
                      {plan.name}
                    </h3>
                    <p className="text-slate-600">{plan.description}</p>
                  </div>

                  {/* Preço */}
                  <div className="mb-6">
                    <div className="flex items-baseline gap-2">
                      <span className="text-5xl font-bold text-slate-900">
                        R$ {price}
                      </span>
                      <span className="text-slate-600">
                        /{billingPeriod === 'monthly' ? 'mês' : 'ano'}
                      </span>
                    </div>
                    {billingPeriod === 'yearly' && savings > 0 && (
                      <p className="text-sm text-green-600 font-medium mt-2">
                        Economize R$ {savings}/ano
                      </p>
                    )}
                  </div>

                  {/* Botão de Assinatura */}
                  <Button
                    onClick={() => handleSubscribe(priceId, plan.name)}
                    disabled={isLoading}
                    className={`w-full h-12 text-base font-semibold transition-all ${
                      plan.popular
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700'
                        : 'bg-slate-900 hover:bg-slate-800'
                    }`}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processando...
                      </>
                    ) : (
                      'Começar Agora'
                    )}
                  </Button>

                  {/* Features */}
                  <div className="mt-8 space-y-3">
                    {plan.features.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-slate-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer do Card */}
                <div className="bg-slate-50 px-8 py-4 border-t border-slate-200">
                  <p className="text-sm text-slate-600 text-center">
                    Cancele quando quiser • Sem taxa de setup
                  </p>
                </div>
              </Card>
            );
          })}
        </div>

        {/* FAQ/Info Adicional */}
        <div className="mt-16 text-center">
          <p className="text-slate-600 mb-4">
            Dúvidas sobre os planos?{' '}
            <a href="/contato" className="text-blue-600 hover:underline font-medium">
              Entre em contato
            </a>
          </p>
          <div className="flex items-center justify-center gap-8 text-sm text-slate-500">
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-600" />
              <span>Pagamento seguro via Stripe</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-600" />
              <span>Garantia de 7 dias</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
