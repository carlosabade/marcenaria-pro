import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Loader2, XCircle } from 'lucide-react';

export default function CheckoutSuccess() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('Processando seu pagamento...');

  const sessionId = searchParams.get('session_id');

  useEffect(() => {
    if (!sessionId) {
      setStatus('error');
      setMessage('Sessão de checkout não encontrada');
      return;
    }

    verifyPayment();
  }, [sessionId]);

  const verifyPayment = async () => {
    try {
      // Aguarda alguns segundos para o webhook processar
      await new Promise(resolve => setTimeout(resolve, 3000));

      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      // Verifica se a assinatura foi criada
      const { data: subscription, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error || !subscription) {
        // Tenta novamente após mais alguns segundos
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const { data: retryData, error: retryError } = await supabase
          .from('subscriptions')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (retryError || !retryData) {
          throw new Error('Assinatura não encontrada');
        }
      }

      setStatus('success');
      setMessage('Pagamento confirmado! Sua assinatura está ativa.');
      
      // Redireciona para dashboard após 2 segundos
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);

    } catch (error) {
      console.error('Erro ao verificar pagamento:', error);
      setStatus('error');
      setMessage('Erro ao processar pagamento. Entre em contato com o suporte.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8">
        <div className="text-center">
          {status === 'loading' && (
            <>
              <div className="mb-6 flex justify-center">
                <Loader2 className="h-16 w-16 text-blue-600 animate-spin" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900 mb-2">
                Processando Pagamento
              </h1>
              <p className="text-slate-600">{message}</p>
            </>
          )}

          {status === 'success' && (
            <>
              <div className="mb-6 flex justify-center">
                <CheckCircle className="h-16 w-16 text-green-600" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900 mb-2">
                Pagamento Confirmado!
              </h1>
              <p className="text-slate-600 mb-6">{message}</p>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-green-800">
                  Você já pode acessar todas as funcionalidades do Marcenaria Pro!
                </p>
              </div>
              <Button
                onClick={() => navigate('/dashboard')}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              >
                Ir para o Dashboard
              </Button>
            </>
          )}

          {status === 'error' && (
            <>
              <div className="mb-6 flex justify-center">
                <XCircle className="h-16 w-16 text-red-600" />
              </div>
              <h1 className="text-2xl font-bold text-slate-900 mb-2">
                Erro no Pagamento
              </h1>
              <p className="text-slate-600 mb-6">{message}</p>
              <div className="space-y-3">
                <Button
                  onClick={() => navigate('/pricing')}
                  variant="outline"
                  className="w-full"
                >
                  Tentar Novamente
                </Button>
                <Button
                  onClick={() => navigate('/contato')}
                  className="w-full bg-slate-900 hover:bg-slate-800"
                >
                  Contatar Suporte
                </Button>
              </div>
            </>
          )}
        </div>
      </Card>
    </div>
  );
}
